using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Input;
using ICSharpCode.AvalonEdit.Highlighting;
using Markdig;

namespace CodeExecutor
{
    public enum SubmissionStatus { None, Success, Fail }

    public class Problem : INotifyPropertyChanged
    {
        public string Number { get; set; }
        public string Title { get; set; }
        public string FilePath { get; set; }

        private SubmissionStatus _status;
        public SubmissionStatus Status
        {
            get => _status;
            set
            {
                if (_status != value)
                {
                    _status = value;
                    OnPropertyChanged();
                }
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
    }

    public partial class MainWindow : Window
    {
        private readonly ObservableCollection<Problem> AllProblems = new ObservableCollection<Problem>();
        public ObservableCollection<Problem> FilteredProblems { get; set; }
                private Problem _currentProblem;
        private string _tempHtmlPath;
                private static string _appRoot;
        private static string _statusDbPath;
        private static Dictionary<string, SubmissionStatus> _problemStatuses = new Dictionary<string, SubmissionStatus>();

        public MainWindow()
        {
            InitializeComponent();
            FilteredProblems = new ObservableCollection<Problem>();
            this.DataContext = this;
            LoadProblems();
            InitializeWebView();
            LanguageSelector.SelectedIndex = 0;

            CodeEditor.TextArea.TextEntering += TextArea_TextEntering;
        }

        private void TextArea_TextEntering(object sender, TextCompositionEventArgs e)
        {
            if (e.Text == "\n")
            {
                var prevLine = CodeEditor.Document.GetLineByOffset(CodeEditor.CaretOffset).PreviousLine;
                if (prevLine != null)
                {
                    string prevLineText = CodeEditor.Document.GetText(prevLine.Offset, prevLine.Length);
                    string indentation = new string(' ', prevLineText.Length - prevLineText.TrimStart().Length);

                    if (prevLineText.Trim().EndsWith("{") || prevLineText.Trim().EndsWith("["))
                    {
                        indentation += "    ";
                    }

                    e.Handled = true;
                    CodeEditor.Document.Insert(CodeEditor.CaretOffset, "\n" + indentation);
                }
            }
            else if (e.Text.Length > 0)
            {
                e.Handled = true;
                switch (e.Text)
                {
                    case "(": 
                        CodeEditor.Document.Insert(CodeEditor.CaretOffset, "()");
                        break;
                    case "{": 
                        CodeEditor.Document.Insert(CodeEditor.CaretOffset, "{}");
                        break;
                    case "[": 
                        CodeEditor.Document.Insert(CodeEditor.CaretOffset, "[]");
                        break;
                    default: 
                        e.Handled = false; 
                        break;
                }

                if (e.Handled)
                {
                    CodeEditor.CaretOffset--;
                }
            }
        }

        private string FindAppRoot()
        {
            if (!string.IsNullOrEmpty(_appRoot)) return _appRoot;

            var currentDir = new DirectoryInfo(AppDomain.CurrentDomain.BaseDirectory);
            while (currentDir != null)
            {
                if (Directory.Exists(Path.Combine(currentDir.FullName, "problems")))
                {
                    _appRoot = currentDir.FullName;
                    _statusDbPath = Path.Combine(_appRoot, "problem_status.json");
                    return _appRoot;
                }
                currentDir = currentDir.Parent;
            }
            // Fallback if the structure is unexpected
            _appRoot = Directory.GetCurrentDirectory();
            _statusDbPath = Path.Combine(_appRoot, "problem_status.json");
            return _appRoot;
        }

        private async void InitializeWebView()
        {
            await ProblemWebView.EnsureCoreWebView2Async(null);
        }

        private void LoadProblems()
        {
            var rootPath = FindAppRoot();
            var problemsDirectory = new DirectoryInfo(Path.Combine(rootPath, "problems"));
            if (!problemsDirectory.Exists) return;

            // Load statuses from JSON file
            if (File.Exists(_statusDbPath))
            {
                try
                {
                    var json = File.ReadAllText(_statusDbPath);
                    _problemStatuses = System.Text.Json.JsonSerializer.Deserialize<Dictionary<string, SubmissionStatus>>(json) ?? new Dictionary<string, SubmissionStatus>();
                }
                catch { /* Ignore errors reading status file */ }
            }

            var files = problemsDirectory.GetFiles("*.md", SearchOption.AllDirectories);
            foreach (var file in files)
            {
                var parts = file.Name.Split(new[] { '.' }, 2);
                if (parts.Length == 2)
                {
                    var problemNumber = parts[0];
                    var status = _problemStatuses.TryGetValue(problemNumber, out var s) ? s : SubmissionStatus.None;

                    var problem = new Problem
                    {
                        Number = problemNumber,
                        Title = Path.GetFileNameWithoutExtension(parts[1]).Trim(),
                        FilePath = file.FullName,
                        Status = status
                    };
                    AllProblems.Add(problem);
                    FilteredProblems.Add(problem);
                }
            }
        }

        private void SearchBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            var searchText = (sender as TextBox)?.Text.ToLower() ?? "";
            FilteredProblems.Clear();
            var filtered = AllProblems.Where(p =>
                p.Number.StartsWith(searchText) ||
                p.Title.ToLower().Contains(searchText));
            foreach (var problem in filtered)
            {
                FilteredProblems.Add(problem);
            }
        }

        private void ProblemsListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var selectedProblem = (sender as ListView)?.SelectedItem as Problem;
            if (selectedProblem == null) return; // Only act on a valid selection

            _currentProblem = selectedProblem; // Now set the class-level field

            var markdownContent = File.ReadAllText(_currentProblem.FilePath);
            var problemDirectory = Path.GetDirectoryName(_currentProblem.FilePath);

            var foreground = ((SolidColorBrush)FindResource("MaterialDesignBody")).Color;
            var paper = ((SolidColorBrush)FindResource("MaterialDesignPaper")).Color;
            var secondary = ((SolidColorBrush)FindResource("MaterialDesignDivider")).Color;

            var htmlContent = $@"
                <style>
                    body {{
                        font-family: sans-serif;
                        background-color: #{paper.R:X2}{paper.G:X2}{paper.B:X2};
                        color: #{foreground.R:X2}{foreground.G:X2}{foreground.B:X2};
                        line-height: 1.6;
                    }}
                    pre {{
                        background-color: #f5f5f5; /* Light Gray */
                        color: #333333; /* Dark Gray Text */
                        font-family: monospace;
                        padding: 15px;
                        border: 1px solid #ddd;
                        border-radius: 5px;
                        white-space: pre-wrap;
                        word-wrap: break-word;
                    }}
                    code {{
                        font-family: monospace;
                    }}
                    h1, h2, h3 {{
                        border-bottom: 1px solid #{secondary.R:X2}{secondary.G:X2}{secondary.B:X2};
                        padding-bottom: 5px;
                    }}
                </style>
                {Markdown.ToHtml(markdownContent)}";

            _tempHtmlPath = Path.Combine(problemDirectory, $"problem-view-temp.html");
            File.WriteAllText(_tempHtmlPath, htmlContent);
            ProblemWebView.Source = new Uri(_tempHtmlPath);

            LanguageSelector.SelectedIndex = 0;
            LoadCodeForProblemAndLanguage(); // Manually trigger load for new problem

            SearchView.Visibility = Visibility.Collapsed;
            CodingView.Visibility = Visibility.Visible;

            (sender as ListView).SelectedItem = null;
        }

        private void BackToSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Clean up the temporary HTML file first
                ProblemWebView.Source = new Uri("about:blank"); // Navigate away to release file lock
                if (!string.IsNullOrEmpty(_tempHtmlPath) && File.Exists(_tempHtmlPath))
                {
                    File.Delete(_tempHtmlPath);
                    _tempHtmlPath = null;
                }
            }
            catch (Exception ex)
            {
                // Log or handle the error, for now, we can ignore it to ensure UI transition happens
                System.Diagnostics.Debug.WriteLine($"Error during cleanup: {ex.Message}");
            }
            finally
            {
                // Ensure the UI transition happens even if cleanup fails
                CodingView.Visibility = Visibility.Collapsed;
                SearchView.Visibility = Visibility.Visible;
                _currentProblem = null;
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (_currentProblem == null) return;

            var languageItem = LanguageSelector.SelectedItem as ComboBoxItem;
            var language = languageItem?.Content.ToString();
            if (string.IsNullOrEmpty(language)) return;

            string extension = GetExtensionForLanguage(language);

            try
            {
                var problemDirectory = Path.GetDirectoryName(_currentProblem.FilePath);
                var solutionFilePath = Path.Combine(problemDirectory, $"{_currentProblem.Number}{extension}");
                File.WriteAllText(solutionFilePath, CodeEditor.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error saving file: {ex.Message}", "Save Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private string GetExtensionForLanguage(string language)
        {
            switch (language)
            {
                case "C++": return ".cpp";
                case "C": return ".c";
                case "Python": return ".py";
                case "Java": return ".java";
                default: return ".txt";
            }
        }

        private void LoadCodeForProblemAndLanguage()
        {
            if (_currentProblem == null || LanguageSelector.SelectedItem is not ComboBoxItem selectedItem)
            {
                CodeEditor.Text = "";
                return;
            }
            var selectedLanguage = selectedItem.Content.ToString();

            string extension = GetExtensionForLanguage(selectedLanguage);
            try
            {
                var problemDirectory = Path.GetDirectoryName(_currentProblem.FilePath);
                var solutionFilePath = Path.Combine(problemDirectory, $"{_currentProblem.Number}{extension}");
                if (File.Exists(solutionFilePath))
                {
                    CodeEditor.Text = File.ReadAllText(solutionFilePath);
                }
                else
                {
                    CodeEditor.Text = ""; // Clear editor if no file found
                }
            }
            catch
            {
                CodeEditor.Text = ""; // Clear on error
            }
        }

        private void LanguageSelector_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (LanguageSelector.SelectedItem is not ComboBoxItem selectedItem) return;
            var selectedLanguage = selectedItem.Content.ToString();

            // Set syntax highlighting
            string syntaxHighlighting = null;
            if (selectedLanguage == "C++" || selectedLanguage == "C")
                syntaxHighlighting = "C++";
            else if (selectedLanguage == "Python")
                syntaxHighlighting = "Python";
            else if (selectedLanguage == "Java")
                syntaxHighlighting = "Java";
            CodeEditor.SyntaxHighlighting = HighlightingManager.Instance.GetDefinition(syntaxHighlighting);

            // Load code
            LoadCodeForProblemAndLanguage();
        }

        private string WrapSnippet(string code, string language)
        {
            if (language == "C++")
            {
                if (code.Contains("int main")) return code;
                return "#include <iostream>\n" +
                       "#include <string>\n" +
                       "#include <vector>\n" +
                       "#include <algorithm>\n" +
                       "#include <cmath>\n\n" +
                       "using namespace std;\n\n" +
                       "int main() {\n" +
                       "    ios_base::sync_with_stdio(false);\n" +
                       "    cin.tie(NULL);\n" +
                       "    " + code + "\n" +
                       "    return 0;\n" +
                       "}";
            }
            if (language == "C")
            {
                if (code.Contains("int main")) return code;
                return "#include <stdio.h>\n" +
                       "#include <stdlib.h>\n" +
                       "#include <string.h>\n" +
                       "#include <math.h>\n\n" +
                       "int main() {\n" +
                       "    " + code + "\n" +
                       "    return 0;\n" +
                       "}";
            }
            return code;
        }

        private async void SubmitButton_Click(object sender, RoutedEventArgs e)
        {
            if (_currentProblem == null) return;

            SubmitButton.IsEnabled = false;
            UpdateResultPanel("Judging...", "", Brushes.Gray);
            string tempDir = Path.Combine(Path.GetTempPath(), "CodeExecutor", Guid.NewGuid().ToString());

            try
            {
                Directory.CreateDirectory(tempDir);
                var language = (LanguageSelector.SelectedItem as ComboBoxItem)?.Content.ToString();
                var sourceCode = CodeEditor.Text;

                var fullCode = WrapSnippet(sourceCode, language);

                var (executablePath, compileError) = await CompileCodeAsync(language, fullCode, tempDir);

                if (!string.IsNullOrEmpty(compileError))
                {
                    UpdateResultPanel("Compilation Error", compileError, Brushes.Red);
                    _currentProblem.Status = SubmissionStatus.Fail;
                    await UpdateAndSaveStatus(_currentProblem.Number, SubmissionStatus.Fail);
                }
                else
                {
                                        var testCaseDir = new FileInfo(_currentProblem.FilePath).Directory.FullName;
                    var testCasePattern = "*.in";
                    var testCases = Directory.GetFiles(testCaseDir, testCasePattern);

                    if (testCases.Length == 0)
                    {
                        UpdateResultPanel("No Test Cases", "No '.in' files found for this problem.", Brushes.Orange);
                        return;
                    }

                    bool allPassed = true;
                    for (int i = 0; i < testCases.Length; i++)
                    {
                        var inFile = testCases[i];
                        var outFile = Path.ChangeExtension(inFile, ".out");
                        if (!File.Exists(outFile)) continue;

                        UpdateResultPanel($"Running Test Case #{i + 1}...", "", Brushes.Gray);
                        var input = await File.ReadAllTextAsync(inFile);
                        var expectedOutput = await File.ReadAllTextAsync(outFile);

                        var (actualOutput, runError) = await RunTestAsync(executablePath, language, input);

                        if (!string.IsNullOrEmpty(runError) || !Normalize(actualOutput).Equals(Normalize(expectedOutput)))
                        {
                            var errorDetails = $"Expected:\n{expectedOutput}\n\nGot:\n{actualOutput}";
                            if (!string.IsNullOrEmpty(runError)) errorDetails += $"\n\nError Log:\n{runError}";
                            UpdateResultPanel($"Fail: Test Case #{i + 1}", errorDetails, Brushes.Red);
                            _currentProblem.Status = SubmissionStatus.Fail;
                            allPassed = false;
                            break;
                        }
                    }

                    if (allPassed)
                    {
                        UpdateResultPanel("Success", "All test cases passed!", Brushes.Green);
                        _currentProblem.Status = SubmissionStatus.Success;
                        await UpdateAndSaveStatus(_currentProblem.Number, SubmissionStatus.Success);
                    }
                    else
                    {
                        await UpdateAndSaveStatus(_currentProblem.Number, SubmissionStatus.Fail);
                    }
                }
            }
            catch (Exception ex)
            {
                UpdateResultPanel("Critical Error", ex.Message, Brushes.Red);
                _currentProblem.Status = SubmissionStatus.Fail;
            }
            finally
            {
                if (Directory.Exists(tempDir))
                {
                    try { Directory.Delete(tempDir, true); } catch { /* Ignore cleanup errors */ }
                }
                SubmitButton.IsEnabled = true;
            }
        }

        private void UpdateResultPanel(string status, string details, Brush statusColor)
        {
            ResultStatusText.Text = status;
            ResultStatusText.Foreground = statusColor;

            ResultDetailsBox.Document.Blocks.Clear();

            if (status.StartsWith("Fail: Test Case"))
            {
                var parts = details.Split(new[] { "\n\nGot:\n" }, StringSplitOptions.None);
                var expected = parts[0].Replace("Expected:\n", "");
                var rest = parts.Length > 1 ? parts[1].Split(new[] { "\n\nError Log:\n" }, StringSplitOptions.None) : new string[0];
                var got = rest.Length > 0 ? rest[0] : "";
                var errorLog = rest.Length > 1 ? rest[1] : "";

                AppendColoredText("Expected:\n", Brushes.LightGray);
                AppendColoredText(expected + "\n", (Brush)new BrushConverter().ConvertFrom("#50fa7b")); // Dracula Green
                AppendColoredText("Got:\n", Brushes.LightGray);
                AppendColoredText(got + "\n", (Brush)new BrushConverter().ConvertFrom("#ff5555")); // Dracula Red
                if (!string.IsNullOrEmpty(errorLog))
                {
                    AppendColoredText("Error Log:\n", Brushes.LightGray);
                    AppendColoredText(errorLog, (Brush)new BrushConverter().ConvertFrom("#ffb86c")); // Dracula Orange
                }
            }
            else
            {
                AppendColoredText(details, Brushes.WhiteSmoke);
            }
        }

        private void AppendColoredText(string text, Brush brush)
        {
            var run = new System.Windows.Documents.Run(text) { Foreground = brush };
            var paragraph = new System.Windows.Documents.Paragraph(run);
            ResultDetailsBox.Document.Blocks.Add(paragraph);
        }

        private async Task UpdateAndSaveStatus(string problemNumber, SubmissionStatus status)
        {
            _problemStatuses[problemNumber] = status;
            try
            {
                var json = System.Text.Json.JsonSerializer.Serialize(_problemStatuses, new System.Text.Json.JsonSerializerOptions { WriteIndented = true });
                await File.WriteAllTextAsync(_statusDbPath, json);
            }
            catch { /* Ignore errors saving status */ }
        }

        private static readonly Dictionary<string, string> CompilerPathCache = new Dictionary<string, string>();

        private string FindCompiler(string compilerExe)
        {
            if (CompilerPathCache.TryGetValue(compilerExe, out var path)) return path;

            var searchRoots = new[]
            {
                @"C:\msys64\mingw64\bin",
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "scoop\\apps")
            };

            foreach (var root in searchRoots)
            {
                if (!Directory.Exists(root)) continue;
                try
                {
                    var files = Directory.GetFiles(root, compilerExe, SearchOption.AllDirectories);
                    if (files.Length > 0)
                    {
                        var foundPath = files.FirstOrDefault(f => f.Contains("mingw", StringComparison.OrdinalIgnoreCase)) ?? files[0];
                        CompilerPathCache[compilerExe] = foundPath;
                        return foundPath;
                    }
                }
                catch (UnauthorizedAccessException) { /* Skip folders we can't access */ }
            }
            
            try
            {
                using (var process = new Process { StartInfo = new ProcessStartInfo(compilerExe, "--version") { UseShellExecute = false, CreateNoWindow = true, RedirectStandardOutput = true, RedirectStandardError = true } })
                {
                    process.Start();
                    process.WaitForExit(1000);
                    path = compilerExe;
                    CompilerPathCache[compilerExe] = path;
                    return path;
                }
            }
            catch
            {
                // Not in PATH
            }

            return null;
        }

        private async Task<(string, string)> CompileCodeAsync(string language, string sourceCode, string tempDir)
        {
            string sourceFile, executablePath, compilerExe, arguments;
            switch (language)
            {
                case "C++":
                    compilerExe = "g++.exe";
                    sourceFile = Path.Combine(tempDir, "source.cpp");
                    executablePath = Path.Combine(tempDir, "program.exe");
                    await File.WriteAllTextAsync(sourceFile, sourceCode);
                    arguments = $"-std=c++17 \"{sourceFile}\" -o \"{executablePath}\"";
                    break;
                case "C":
                    compilerExe = "gcc.exe";
                    sourceFile = Path.Combine(tempDir, "source.c");
                    executablePath = Path.Combine(tempDir, "program.exe");
                    await File.WriteAllTextAsync(sourceFile, sourceCode);
                    arguments = $"\"{sourceFile}\" -o \"{executablePath}\"";
                    break;
                case "Python":
                    compilerExe = "python.exe";
                    sourceFile = Path.Combine(tempDir, "source.py");
                    await File.WriteAllTextAsync(sourceFile, sourceCode);
                    return (sourceFile, null);
                case "Java":
                    compilerExe = "javac.exe";
                    sourceFile = Path.Combine(tempDir, "Main.java");
                    executablePath = "Main";
                    await File.WriteAllTextAsync(sourceFile, sourceCode);
                    arguments = $"\"{sourceFile}\"";
                    break;
                default:
                    return (null, "Language not supported.");
            }

            var compilerPath = FindCompiler(compilerExe);
            if (compilerPath == null)
            {
                return (null, $"Compiler '{compilerExe}' not found. Please ensure it is installed in a standard location (MSYS2, Scoop) or is in your system PATH.");
            }

            var (output, error) = await RunProcessAsync(compilerPath, arguments, tempDir);

            if (!string.IsNullOrEmpty(error))
            {
                return (null, error);
            }

            var expectedOutputFile = (language == "Java")
                ? Path.Combine(tempDir, "Main.class")
                : executablePath;

            if (language != "Python" && !File.Exists(expectedOutputFile))
            {
                var errorMessage = "Compiler did not produce an output file, even though no direct error was reported.\n" +
                                   "This can be caused by an incomplete compiler installation (e.g., missing linker) or a critical error in the source code.\n" +
                                   $"Compiler output (stdout):\n{output}";
                return (null, errorMessage);
            }

            return (executablePath, null);
        }

        private async Task<(string, string)> RunTestAsync(string executablePath, string language, string input)
        {
            string command, arguments;
            string workingDir = Path.GetDirectoryName(executablePath);
            switch (language)
            {
                case "Python":
                    // Try to find 'py.exe' (Python Launcher) first, as it handles environments better.
                    var pythonLauncherPath = FindCompiler("py.exe");
                    if (pythonLauncherPath != null)
                    {
                        command = pythonLauncherPath;
                        arguments = $"-3 \"{executablePath}\""; // Use -3 to ensure Python 3
                    }
                    else
                    {
                        // Fallback to python.exe if py.exe is not found
                        var pythonPath = FindCompiler("python.exe");
                        command = pythonPath ?? "python";
                        arguments = $"\"{executablePath}\"";
                    }
                    break;
                case "Java":
                    var javaPath = FindCompiler("java.exe");
                    command = javaPath ?? "java";
                    arguments = executablePath;
                    break;
                default:
                    command = executablePath;
                    arguments = "";
                    break;
            }
            return await RunProcessAsync(command, arguments, workingDir, input, 2000);
        }

        private async Task<(string, string)> RunProcessAsync(string command, string arguments, string workingDir, string input = null, int timeout = 5000)
        {
            var processInfo = new ProcessStartInfo
            {
                FileName = command,
                Arguments = arguments,
                WorkingDirectory = workingDir,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                RedirectStandardInput = input != null,
                UseShellExecute = false,
                CreateNoWindow = true,
                StandardOutputEncoding = Encoding.UTF8,
                StandardErrorEncoding = Encoding.UTF8
            };

            using (var process = new Process { StartInfo = processInfo })
            {
                process.Start();

                if (input != null)
                {
                    await process.StandardInput.WriteAsync(input);
                    process.StandardInput.Close();
                }

                var outputTask = process.StandardOutput.ReadToEndAsync();
                var errorTask = process.StandardError.ReadToEndAsync();

                var processExitTask = process.WaitForExitAsync();
                var completedTask = await Task.WhenAny(processExitTask, Task.Delay(timeout));

                if (completedTask != processExitTask)
                {
                    try { process.Kill(); } catch { }
                    return (await outputTask, "Time Limit Exceeded.");
                }

                await Task.WhenAll(outputTask, errorTask);

                return (outputTask.Result, errorTask.Result);
            }
        }

        private string Normalize(string s)
        {
            return s.Trim().Replace("\r\n", "\n");
        }
    }
}
