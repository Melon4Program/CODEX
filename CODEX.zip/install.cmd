@echo off

:: ----------------------------------------------------------------
:: Self-elevate to Administrator
:: ----------------------------------------------------------------
>nul 2>&1 "%SYSTEMROOT%\system32\cacls.exe" "%SYSTEMROOT%\system32\config\system"
if '%errorlevel%' NEQ '0' (
    echo Requesting administrative privileges...
    goto UACPrompt
) else ( goto gotAdmin )

:UACPrompt
    echo Set UAC = CreateObject^("Shell.Application"^) > "%temp%\getadmin.vbs"
    echo UAC.ShellExecute "%~s0", "", "", "runas", 1 >> "%temp%\getadmin.vbs"
    "%temp%\getadmin.vbs"
    exit /B

:gotAdmin
    if exist "%temp%\getadmin.vbs" ( del "%temp%\getadmin.vbs" )
    pushd "%CD%"
    CD /D "%~dp0"

:: ----------------------------------------------------------------
:: Main Installer Logic
:: ----------------------------------------------------------------
cls
echo.
 echo  ================================
 echo      CODEX Installer
 echo  ================================
 echo.
 echo  TERMS OF USE
 echo  --------------------------------
 echo  1. This software is provided "as is", without warranty of any kind.
 echo  2. The user assumes all risk for the use of this software.
 echo  3. You may not reverse engineer, decompile, or disassemble this software.
 echo  4. This software is for personal, non-commercial use only.
 echo.
 echo  By continuing with this installation, you agree to these terms.
 echo  --------------------------------
 echo.

set /p "agree=Do you accept the terms and wish to continue? (Y/N): "
if /i not "%agree%"=="y" (
    echo Installation cancelled by user.
    pause
    exit
)

:: --- Installation ---
set "installPath=C:\Program Files\CODEX"
set "sourcePath=%~dp0bin\Release\net8.0-windows\win-x64\publish"

echo.
 echo Creating installation directory: %installPath%
mkdir "%installPath%"

echo.
 echo Copying application files...
xcopy /E /I /Y /Q "%sourcePath%" "%installPath%\"

echo.
 echo Creating Desktop shortcut...
set "shortcutPath=%USERPROFILE%\Desktop\CODEX.lnk"
set "targetPath=%installPath%\CODEX.exe"
set "psCommand=$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut('%shortcutPath%'); $s.TargetPath = '%targetPath%'; $s.IconLocation = '%targetPath%,0'; $s.Save()"
powershell -NoProfile -Command "%psCommand%" >nul

echo.
 echo  ================================
 echo      Installation Complete!
 echo  ================================
 echo.
 echo  You can now run CODEX from the shortcut on your Desktop.
 echo.
pause
popd
